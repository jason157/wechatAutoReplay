"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import render_template
from wechatAutoReplay import app

from flask import request
import hashlib



@app.route('/wechat', methods=["GET","POST"])
def wechat():
    """wechat page"""
    if request.method == "GET":
        signature = request.args.get("signature")
        timestamp = request.args.get("timestamp")
        nonce = request.args.get("nonce")
        echostr = request.args.get("echostr")

        token = "jasonwechat"

        data = [token, timestamp, nonce]
        print(data)
        
        temp = ''.join(data)
        print(temp)
        temp_signature=hashlib.sha1(temp.encode('utf-8')).hexdigest()
        print(signature, temp_signature)
        if signature == temp_signature:
            print(echostr)
            return echostr
        else:
            return echostr
            

@app.route('/test')
def test():
    """wechat page"""
    str1 = "123"
    sha = hashlib.sha1(str1.encode('utf-8'))
    encrypts = sha.hexdigest()
    print(encrypts)
    return encrypts