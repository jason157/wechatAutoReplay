

def repalyTemplate():
    '''
    按微信XML格式相应
    '''
    pass

def getRequest():
    '''
    获取到微信传输的请求，并解析
    '''
    pass

def findAnwser():
    '''
    再数据库中查找到答案，并返回
    '''
    pass
